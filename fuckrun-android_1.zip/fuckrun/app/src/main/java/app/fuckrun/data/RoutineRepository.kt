package app.fuckrun.data

import app.fuckrun.data.db.*
import app.fuckrun.domain.OnboardingAnswers
import app.fuckrun.domain.RecommendationEngine
import app.fuckrun.domain.SessionType
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

enum class PlanState { DONE, MISSED, PENDING, REST }

/** Estado de una sesión planificada: los descansos y las futuras nunca cuentan como fallos. */
fun PlannedSessionEntity.state(today: LocalDate = LocalDate.now()): PlanState = when {
    type == SessionType.REST.name -> PlanState.REST
    linkedRunId != null -> PlanState.DONE
    epochDay < today.toEpochDay() -> PlanState.MISSED
    else -> PlanState.PENDING
}

data class Compliance(val done: Int, val missed: Int, val pending: Int, val rest: Int) {
    val trainings get() = done + missed + pending
}

fun compliance(list: List<PlannedSessionEntity>, from: LocalDate, to: LocalDate, today: LocalDate = LocalDate.now()): Compliance {
    val inRange = list.filter { it.epochDay in from.toEpochDay()..to.toEpochDay() }
    val s = inRange.groupingBy { it.state(today) }.eachCount()
    return Compliance(s[PlanState.DONE] ?: 0, s[PlanState.MISSED] ?: 0, s[PlanState.PENDING] ?: 0, s[PlanState.REST] ?: 0)
}

class RoutineRepository(private val db: AppDatabase) {
    private val dao = db.routines()
    fun routines() = dao.routines()
    fun planned() = dao.allPlanned()
    suspend fun plannedOnce() = dao.allPlannedOnce()
    suspend fun get(id: Long) = dao.planned(id)

    suspend fun createManual(name: String, kind: String, start: LocalDate, end: LocalDate) =
        dao.insert(RoutineEntity(name = name, kind = kind, startEpochDay = start.toEpochDay(), endEpochDay = end.toEpochDay()))

    /** Crea una rutina desde la plantilla compatible con el formulario. Repite la semana tipo sin aumentar la carga. */
    suspend fun createFromTemplate(a: OnboardingAnswers, weeks: Int, start: LocalDate): Long {
        val week = RecommendationEngine.weekly(a)
        val monday = start.with(TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY))
        val end = monday.plusWeeks(weeks.toLong()).minusDays(1)
        val tpl = week.days.firstOrNull()?.second?.templateId
        val id = dao.insert(RoutineEntity(name = "Rutina de $weeks semanas", kind = if (weeks == 4) "MONTHLY" else if (weeks == 1) "WEEKLY" else "CUSTOM",
            startEpochDay = monday.toEpochDay(), endEpochDay = end.toEpochDay(), templateId = tpl))
        val items = mutableListOf<PlannedSessionEntity>()
        for (w in 0 until weeks) {
            val trainingDays = week.days.map { it.first }.toSet()
            for (d in 0 until 7) {
                val date = monday.plusWeeks(w.toLong()).plusDays(d.toLong())
                if (date.isBefore(start)) continue
                val p = week.days.firstOrNull { it.first == date.dayOfWeek }?.second
                items += if (p != null) PlannedSessionEntity(routineId = id, name = p.title, epochDay = date.toEpochDay(), type = p.type.name,
                    targetMinutes = p.mainMinutes, intensity = p.intensity.name, structure = p.structure)
                else if (date.dayOfWeek !in trainingDays) PlannedSessionEntity(routineId = id, name = "Descanso", epochDay = date.toEpochDay(), type = SessionType.REST.name)
                else continue
            }
        }
        dao.insertPlannedAll(items)
        return id
    }

    suspend fun add(p: PlannedSessionEntity) = dao.insertPlanned(p)
    suspend fun update(p: PlannedSessionEntity) = dao.updatePlanned(p)
    suspend fun delete(id: Long) = dao.deletePlanned(id)
    suspend fun deleteRoutine(id: Long) = dao.delete(id)
    suspend fun duplicate(p: PlannedSessionEntity, toDay: LocalDate) =
        dao.insertPlanned(p.copy(id = 0, epochDay = toDay.toEpochDay(), linkedRunId = null, skipped = false))
    suspend fun reschedule(p: PlannedSessionEntity, toDay: LocalDate) = dao.updatePlanned(p.copy(epochDay = toDay.toEpochDay()))

    /**
     * Vincula una actividad registrada con una sesión planificada elegida por el usuario.
     * Evita dobles marcas: una actividad solo puede cubrir una sesión y viceversa.
     * Cambiar la rutina después no modifica la actividad registrada.
     */
    suspend fun link(plannedId: Long, runId: Long): Boolean {
        val p = dao.planned(plannedId) ?: return false
        if (p.linkedRunId != null && p.linkedRunId != runId) return false
        if (p.type == SessionType.REST.name) return false
        dao.unlinkRun(runId)
        dao.updatePlanned(p.copy(linkedRunId = runId))
        db.runs().get(runId)?.let { db.runs().update(it.copy(plannedSessionId = plannedId)) }
        return true
    }

    suspend fun deleteAll() = dao.deleteAll()
}
