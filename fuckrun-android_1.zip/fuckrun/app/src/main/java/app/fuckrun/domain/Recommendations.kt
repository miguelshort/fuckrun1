package app.fuckrun.domain

import java.time.DayOfWeek
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class SessionType(val label: String, val isRest: Boolean = false) {
    WALK_RUN("Caminar y correr"),
    EASY("Rodaje suave"),
    EASY_STRIDES("Rodaje suave con cambios cortos"),
    STEADY("Rodaje tranquilo de duración habitual"),
    WALK("Caminata activa"),
    FREE("Carrera libre"),
    REST("Descanso", isRest = true),
}

/** Intensidad expresada de forma sencilla ("prueba del habla"). */
enum class Intensity(val label: String, val hint: String) {
    VERY_EASY("Muy suave", "Puedes hablar sin esfuerzo."),
    EASY("Suave", "Puedes mantener una conversación con frases completas."),
    MODERATE("Moderada", "Puedes hablar, pero con frases cortas."),
}

data class SessionProposal(
    val templateId: String,
    val type: SessionType,
    val title: String,
    val mainMinutes: Int,
    val structure: String,
    val warmup: String,
    val cooldown: String,
    val intensity: Intensity,
    val restNote: String,
    val explanation: String,
    val usedAnswers: List<String>,
    val cautionNote: String? = null,
) {
    val totalMinutes: Int get() = mainMinutes + 10

    /** Opción "Reducir": ~30 % menos de parte principal y nunca más intensa. */
    fun reduced(): SessionProposal = copy(
        mainMinutes = max(5, (mainMinutes * 0.7).roundToInt()),
        intensity = if (intensity == Intensity.MODERATE) Intensity.EASY else intensity,
        structure = if (type == SessionType.WALK_RUN) "$structure (menos repeticiones)" else "${max(5, (mainMinutes * 0.7).roundToInt())} min seguidos",
        explanation = "Versión reducida. $explanation",
    )

    /** Opción "Cambiar": caminata activa del mismo tiempo. */
    fun asWalk(): SessionProposal = copy(
        type = SessionType.WALK, title = "Caminata activa", intensity = Intensity.EASY,
        structure = "$mainMinutes min caminando a paso vivo", explanation = "Sustituye la carrera por una caminata. $explanation",
    )
}

data class TrainingTemplate(val id: String, val name: String, val level: Level, val summary: String, val source: String)

/**
 * Plantillas de entrenamiento. Procedencia documentada en docs/PLANTILLAS.md.
 * Son orientativas: no constituyen un programa clínico ni garantizan resultados.
 * La carga NUNCA se incrementa automáticamente al completar sesiones.
 */
object Templates {
    val WALK_RUN = TrainingTemplate(
        "walk-run-v1", "Caminar y correr", Level.INICIO,
        "3 sesiones/semana alternando 1–2 min corriendo suave con 2 min caminando.",
        "Enfoque de alternancia caminar/correr usado en programas públicos de iniciación (p. ej., NHS «Couch to 5K»); intensidad por prueba del habla.",
    )
    val BASE = TrainingTemplate(
        "base-v1", "Base continua", Level.BASE,
        "Rodajes suaves de la duración que ya toleras, con 1 día de caminar y correr.",
        "Recomendaciones generales de actividad física de la OMS (2020) y prueba del habla para la intensidad.",
    )
    val CONTINUITY = TrainingTemplate(
        "continuity-v1", "Continuidad", Level.CONTINUIDAD,
        "Rodajes a tu duración habitual y un rodaje con cambios cortos y suaves.",
        "Recomendaciones generales de actividad física de la OMS (2020); estructura conservadora sin progresión automática.",
    )
    val all = listOf(WALK_RUN, BASE, CONTINUITY)
    fun forLevel(l: Level) = when (l) { Level.INICIO -> WALK_RUN; Level.BASE -> BASE; Level.CONTINUIDAD -> CONTINUITY }
}

data class WeeklySuggestion(val days: List<Pair<DayOfWeek, SessionProposal>>, val rule: String, val usedAnswers: List<String>)

/** Motor de reglas local, sin IA. Cada salida indica las respuestas usadas. */
object RecommendationEngine {

    private const val WARMUP = "5 min caminando a paso vivo"
    private const val COOLDOWN = "5 min caminando suave y respiración tranquila"

    fun proposal(a: OnboardingAnswers): SessionProposal {
        val level = LevelClassifier.classify(a).level
        val budget = max(10, a.sessionMinutes - 10)   // 10 min para calentar y volver a la calma
        val used = mutableListOf(
            "Nivel orientativo: ${level.label}",
            "Tiempo por sesión: ${a.sessionMinutes} min",
        )
        val caution = if (a.cautious) "Has indicado algo a tener en cuenta: mantenemos la sesión suave y puedes sustituirla por descanso o por la actividad que te hayan indicado." else null
        if (a.cautious) used += "Limitación indicada (sin detalles)"

        val p = when (level) {
            Level.INICIO -> {
                used += "Tiempo seguido cómodo: ${a.continuous.label}"
                val runMin = if (a.continuous == Continuous.NONE || a.continuous == Continuous.UNKNOWN) 1 else 2
                val reps = max(3, min(8, budget / (runMin + 2)))
                SessionProposal(
                    Templates.WALK_RUN.id, SessionType.WALK_RUN, "Caminar y correr",
                    reps * (runMin + 2),
                    "$reps × ($runMin min corriendo suave + 2 min caminando)",
                    WARMUP, COOLDOWN, Intensity.EASY,
                    "Deja al menos un día de descanso entre sesiones.",
                    "Alternar te permite acumular tiempo corriendo sin exigir distancia ni velocidad.",
                    used, caution,
                )
            }
            Level.BASE -> {
                val tolerated = a.continuous.minutes ?: 10
                used += "Tiempo seguido cómodo: ${a.continuous.label}"
                val main = max(10, min(tolerated, budget))
                SessionProposal(
                    Templates.BASE.id, SessionType.EASY, "Rodaje suave",
                    main, "$main min seguidos a ritmo cómodo", WARMUP, COOLDOWN, Intensity.EASY,
                    "Si necesitas caminar un rato, hazlo: cuenta igual.",
                    "Usamos el tiempo que ya puedes correr cómodo, sin subirlo automáticamente.",
                    used, caution,
                )
            }
            Level.CONTINUIDAD -> {
                val usual = a.continuous.minutes ?: 30
                used += "Tiempo seguido cómodo: ${a.continuous.label}"
                used += "Días que corres ahora: ${a.daysPerWeekNow ?: "No lo sé"}"
                val main = max(20, min(usual, budget))
                SessionProposal(
                    Templates.CONTINUITY.id, SessionType.STEADY, "Rodaje de duración habitual",
                    main, "$main min a ritmo cómodo", WARMUP, COOLDOWN, Intensity.EASY,
                    "Alterna con días de descanso o sesiones más cortas.",
                    "Consolida lo que ya haces con tu duración habitual.",
                    used, caution,
                )
            }
        }
        return if (a.cautious) p.copy(intensity = Intensity.VERY_EASY, mainMinutes = max(5, (p.mainMinutes * 0.75).roundToInt())) else p
    }

    /** Distribuye sesiones en los días disponibles, separándolas cuando es posible. */
    fun weekly(a: OnboardingAnswers): WeeklySuggestion {
        val level = LevelClassifier.classify(a).level
        val maxDays = when (level) { Level.INICIO -> 3; Level.BASE -> 4; Level.CONTINUIDAD -> 5 }
        val target = min(a.desiredDays, maxDays)
        val available = a.availableDays.ifEmpty { DayOfWeek.values().toList() }
        val chosen = spread(available, target)
        val base = proposal(a)
        val days = chosen.mapIndexed { i, d ->
            val p = when {
                level == Level.BASE && i == chosen.lastIndex && chosen.size >= 3 ->
                    base.copy(type = SessionType.WALK_RUN, title = "Caminar y correr",
                        structure = "${max(3, base.mainMinutes / 4)} × (3 min corriendo + 1 min caminando)",
                        explanation = "Una sesión con pausas caminando para variar la carga.")
                level == Level.CONTINUIDAD && i == 1 && !a.cautious ->
                    base.copy(type = SessionType.EASY_STRIDES, title = "Rodaje suave con cambios cortos",
                        structure = "${base.mainMinutes} min suaves; al final 4–6 × 20 s algo más rápidos, recuperando caminando",
                        intensity = Intensity.MODERATE,
                        explanation = "Cambios muy cortos y opcionales; si no te apetece, haz el rodaje sin ellos.")
                else -> base
            }
            d to p
        }
        val used = listOf(
            "Días que quieres entrenar: ${a.desiredDays}",
            "Días disponibles: ${available.joinToString { Fmt.dayShort(it) }}",
            "Nivel orientativo: ${level.label}",
        )
        val rule = "Hasta $maxDays días para el nivel ${level.label}, separados para dejar descanso entre sesiones."
        return WeeklySuggestion(days, rule, used)
    }

    internal fun spread(days: List<DayOfWeek>, n: Int): List<DayOfWeek> {
        val sorted = days.distinct().sortedBy { it.value }
        if (n >= sorted.size) return sorted
        if (n <= 0) return emptyList()
        // Elige n días maximizando la separación mínima (búsqueda exhaustiva: 7 días como mucho).
        var best: List<DayOfWeek> = sorted.take(n)
        var bestScore = -1
        fun gapScore(sel: List<DayOfWeek>): Int {
            if (sel.size < 2) return 7
            val v = sel.map { it.value }
            val gaps = v.zipWithNext { x, y -> y - x } + (v.first() + 7 - v.last())
            return gaps.min()
        }
        fun rec(start: Int, cur: List<DayOfWeek>) {
            if (cur.size == n) { val s = gapScore(cur); if (s > bestScore) { bestScore = s; best = cur }; return }
            for (i in start until sorted.size) rec(i + 1, cur + sorted[i])
        }
        rec(0, emptyList())
        return best
    }
}
