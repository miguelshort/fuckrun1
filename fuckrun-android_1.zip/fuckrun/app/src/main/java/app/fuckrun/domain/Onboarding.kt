package app.fuckrun.domain

import kotlinx.serialization.Serializable
import java.time.DayOfWeek

/** Respuestas del formulario inicial. Todas editables desde el perfil. Ningún campo exige ritmos. */
@Serializable
data class OnboardingAnswers(
    val goal: Goal = Goal.START,
    val targetDistance: TargetDistance? = null,
    val runsNow: RunsNow = RunsNow.NO,
    val daysPerWeekNow: Int? = null,               // null = "No lo sé"
    val continuous: Continuous = Continuous.UNKNOWN,
    val usualDistance: UsualDistance = UsualDistance.UNKNOWN,
    val sessionMinutes: Int = 30,
    val desiredDays: Int = 3,
    val availableDayNumbers: Set<Int> = setOf(1, 3, 6),   // ISO: 1 = lunes … 7 = domingo
    val social: Social = Social.BOTH,
    val environments: Set<Environment> = emptySet(),
    val elevation: Elevation = Elevation.UNKNOWN,
    val routeShape: RouteShape = RouteShape.ANY,
    val municipality: String? = null,
    val province: String? = null,
    val limitation: Limitation = Limitation.NONE,
    val limitationNote: String = "",
    val levelOverride: Level? = null,
) {
    val availableDays: List<DayOfWeek> get() = availableDayNumbers.sorted().map { DayOfWeek.of(it) }
    val cautious: Boolean get() = limitation == Limitation.SOMETHING
}

@Serializable enum class Goal(val label: String) {
    START("Empezar a correr"), CONSISTENCY("Ganar constancia"),
    DISTANCE("Aumentar distancia"), TARGET("Preparar una distancia concreta")
}
@Serializable enum class TargetDistance(val label: String) { K5("5 km"), K10("10 km"), HALF("Media maratón"), MARATHON("Maratón") }
@Serializable enum class RunsNow(val label: String) { NO("No"), SOMETIMES("A veces"), YES("Sí, de forma regular") }
@Serializable enum class Continuous(val label: String, val minutes: Int?) {
    NONE("Todavía no puedo correr seguido", 0), UNDER5("Menos de 5 min", 3), M5_15("5–15 min", 10),
    M15_30("15–30 min", 20), M30_60("30–60 min", 40), OVER60("Más de 60 min", 60), UNKNOWN("No lo sé", null)
}
@Serializable enum class UsualDistance(val label: String) {
    UNKNOWN("No lo sé"), U3("Menos de 3 km"), K3_5("3–5 km"), K5_10("5–10 km"), K10_15("10–15 km"), O15("Más de 15 km")
}
@Serializable enum class Social(val label: String) { SOLO("Solo"), GROUP("En grupo"), BOTH("Ambas") }
@Serializable enum class Environment(val label: String) { PARK("Parques"), CITY("Ciudad"), SEAFRONT("Paseo marítimo"), TRAILS("Caminos") }
@Serializable enum class Elevation(val label: String) { FLAT("Llano"), HILLS("Acepto desnivel"), UNKNOWN("No lo sé") }
@Serializable enum class RouteShape(val label: String) { LOOP("Circular"), OUT_BACK("Ida y vuelta"), ANY("Me da igual") }
@Serializable enum class Limitation(val label: String) {
    NONE("No"), SOMETHING("Sí, algo a tener en cuenta"), PREFER_NOT("Prefiero no indicarlo")
}

@Serializable enum class Level(val label: String, val description: String) {
    INICIO("Inicio", "Todavía no corres o necesitas alternar caminar y correr."),
    BASE("Base", "Ya puedes correr durante periodos cortos de forma cómoda."),
    CONTINUIDAD("Continuidad", "Mantienes sesiones regulares y quieres consolidar o ampliar tu práctica."),
}

data class LevelResult(val level: Level, val reasons: List<String>, val overridden: Boolean)

/**
 * Clasificación orientativa basada SOLO en experiencia y capacidad declaradas.
 * La ciudad y la ubicación no intervienen. No es una evaluación médica.
 */
object LevelClassifier {
    fun classify(a: OnboardingAnswers): LevelResult {
        val reasons = mutableListOf<String>()
        val computed: Level = when {
            a.runsNow == RunsNow.NO && a.continuous.minutes.let { it == null || it < 15 } -> {
                reasons += "Indicas que ahora no corres."
                if (a.continuous != Continuous.UNKNOWN) reasons += "Tiempo seguido cómodo: ${a.continuous.label.lowercase()}."
                Level.INICIO
            }
            a.continuous == Continuous.NONE || a.continuous == Continuous.UNDER5 -> {
                reasons += "Puedes correr seguido ${a.continuous.label.lowercase()}: conviene alternar caminar y correr."
                Level.INICIO
            }
            a.runsNow == RunsNow.YES && (a.daysPerWeekNow ?: 0) >= 3 &&
                (a.continuous.minutes ?: 0) >= 30 -> {
                reasons += "Corres de forma regular, ${a.daysPerWeekNow} días por semana."
                reasons += "Tiempo seguido cómodo: ${a.continuous.label.lowercase()}."
                Level.CONTINUIDAD
            }
            else -> {
                reasons += "Corres ${a.runsNow.label.lowercase()}."
                if (a.continuous == Continuous.UNKNOWN) reasons += "No sabes cuánto puedes correr seguido; partimos de algo prudente."
                else reasons += "Tiempo seguido cómodo: ${a.continuous.label.lowercase()}."
                Level.BASE
            }
        }
        val override = a.levelOverride
        return if (override != null && override != computed) {
            LevelResult(override, listOf("Lo has elegido tú (la propuesta era ${computed.label}).") + reasons, true)
        } else LevelResult(computed, reasons, false)
    }
}
