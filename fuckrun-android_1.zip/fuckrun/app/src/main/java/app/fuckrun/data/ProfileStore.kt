package app.fuckrun.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import app.fuckrun.domain.OnboardingAnswers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.store by preferencesDataStore("profile")

enum class PrimaryMetric(val label: String) { TIME("Tiempo activo"), DISTANCE("Distancia"), PACE("Ritmo actual"), SPEED("Velocidad actual") }

@Serializable
data class AppSettings(
    val onboardingDone: Boolean = false,
    val answers: OnboardingAnswers = OnboardingAnswers(),
    val primaryMetric: PrimaryMetric = PrimaryMetric.TIME,
    val countdown: Boolean = true,
    val remindersEnabled: Boolean = true,
    val sharedDisplayName: String = "",
)

val AppJson = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = false }

class ProfileStore(private val ctx: Context) {
    private val KEY = stringPreferencesKey("settings_json")

    val settings: Flow<AppSettings> = ctx.store.data.map { p ->
        p[KEY]?.let { runCatching { AppJson.decodeFromString<AppSettings>(it) }.getOrNull() } ?: AppSettings()
    }

    suspend fun update(f: (AppSettings) -> AppSettings) {
        ctx.store.edit { p ->
            val cur = p[KEY]?.let { runCatching { AppJson.decodeFromString<AppSettings>(it) }.getOrNull() } ?: AppSettings()
            p[KEY] = AppJson.encodeToString(f(cur))
        }
    }

    suspend fun clear() { ctx.store.edit { it.clear() } }
}
