package app.fuckrun.ui.components

import android.graphics.DashPathEffect
import android.graphics.Paint
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.fuckrun.BuildConfig
import app.fuckrun.data.LatLon
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay

/** Fuente de teselas configurable (ver docs/SERVICIOS.md). Sin URL propia se usa OSM estándar, solo para desarrollo. */
fun appTileSource(): OnlineTileSourceBase {
    val url = BuildConfig.MAP_TILE_URL
    if (url.isBlank()) return TileSourceFactory.MAPNIK
    return object : OnlineTileSourceBase("custom", 0, 20, 256, "", arrayOf(url)) {
        override fun getTileURLString(index: Long): String = url
            .replace("{z}", MapTileIndex.getZoom(index).toString())
            .replace("{x}", MapTileIndex.getX(index).toString())
            .replace("{y}", MapTileIndex.getY(index).toString())
    }
}

data class MapMarker(val point: LatLon, val title: String)

/**
 * Mapa con trazado. Cada segmento registrado se dibuja como línea continua azul; entre segmentos
 * se dibuja una línea discontinua gris que indica un TRAMO SIN DATOS (no un recorrido confirmado).
 */
@Composable
fun RunMap(
    segments: List<List<LatLon>>,
    modifier: Modifier = Modifier,
    markers: List<MapMarker> = emptyList(),
    showGaps: Boolean = true,
    interactive: Boolean = true,
    follow: Boolean = false,
    fallbackCenter: LatLon = LatLon(40.4168, -3.7038),
) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var mapRef by remember { mutableStateOf<MapView?>(null) }
    var fitted by remember { mutableStateOf(false) }
    DisposableEffect(lifecycle, mapRef) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) { Lifecycle.Event.ON_RESUME -> mapRef?.onResume(); Lifecycle.Event.ON_PAUSE -> mapRef?.onPause(); else -> {} }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs); mapRef?.onDetach() }
    }
    Box(modifier.clip(RoundedCornerShape(24.dp)).background(C.Surface)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(appTileSource())
                    setMultiTouchControls(interactive)
                    isClickable = interactive
                    zoomController.setVisibility(org.osmdroid.views.CustomZoomButtonsController.Visibility.NEVER)
                    overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERT_COLORS)   // estilo oscuro
                    overlayManager.tilesOverlay.setLoadingBackgroundColor(C.Surface.toArgb())
                    controller.setZoom(13.0)
                    controller.setCenter(GeoPoint(fallbackCenter.lat, fallbackCenter.lon))
                    mapRef = this
                }
            },
            update = { map ->
                map.overlays.clear()
                val all = mutableListOf<GeoPoint>()
                segments.filter { it.isNotEmpty() }.let { segs ->
                    segs.forEachIndexed { i, seg ->
                        val pts = seg.map { GeoPoint(it.lat, it.lon) }; all += pts
                        if (pts.size >= 2) map.overlays.add(Polyline(map).apply {
                            setPoints(pts); outlinePaint.color = C.Blue.toArgb(); outlinePaint.strokeWidth = 10f
                            outlinePaint.strokeCap = Paint.Cap.ROUND; outlinePaint.isAntiAlias = true
                        })
                        if (showGaps && i < segs.lastIndex) {
                            val a = seg.last(); val b = segs[i + 1].first()
                            map.overlays.add(Polyline(map).apply {
                                setPoints(listOf(GeoPoint(a.lat, a.lon), GeoPoint(b.lat, b.lon)))
                                outlinePaint.color = C.TextSec.copy(alpha = 0.7f).toArgb(); outlinePaint.strokeWidth = 5f
                                outlinePaint.pathEffect = DashPathEffect(floatArrayOf(14f, 14f), 0f)
                                title = "Tramo sin datos"
                            })
                        }
                    }
                }
                markers.forEach { m ->
                    all += GeoPoint(m.point.lat, m.point.lon)
                    map.overlays.add(Marker(map).apply { position = GeoPoint(m.point.lat, m.point.lon); title = m.title
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM) })
                }
                if (follow && all.isNotEmpty()) map.controller.animateTo(all.last())
                else if (!fitted && all.size >= 2) {
                    map.post { runCatching { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(all).increaseByScale(1.3f), false) } }
                    fitted = true
                } else if (!fitted && all.size == 1) { map.controller.setCenter(all.first()); map.controller.setZoom(16.0); fitted = true }
                map.invalidate()
            },
        )
        Text(BuildConfig.MAP_ATTRIBUTION, style = T.Label.copy(fontSize = 10.sp, color = C.TextSec),
            modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(6.dp)).background(C.Bg.copy(alpha = 0.7f)).padding(horizontal = 6.dp, vertical = 2.dp))
    }
}
