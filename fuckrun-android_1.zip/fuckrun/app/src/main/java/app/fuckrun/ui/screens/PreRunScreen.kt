package app.fuckrun.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.location.LocationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.AppSettings
import app.fuckrun.data.PlanState
import app.fuckrun.data.db.RunKind
import app.fuckrun.data.state
import app.fuckrun.domain.Fmt
import app.fuckrun.tracking.SignalQuality
import app.fuckrun.tracking.Tracking
import app.fuckrun.tracking.signalFor
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.delay
import java.time.LocalDate

@SuppressLint("MissingPermission")
@Composable
fun PreRunScreen(nav: NavController, kind0: String, planned0: Long?, route0: String?, shared0: String?, sharedName0: String?) {
    val ctx = LocalContext.current
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val planned by remember { g.routines.planned() }.collectAsStateWithLifecycle(emptyList())
    val favorites by remember { g.db.favorites().all() }.collectAsStateWithLifecycle(emptyList())
    val shared by remember { g.shared.mySessions() }.collectAsStateWithLifecycle(emptyList())

    var kind by remember { mutableStateOf(kind0) }
    var plannedId by remember { mutableStateOf(planned0) }
    var routeId by remember { mutableStateOf(route0) }
    var sharedId by remember { mutableStateOf(shared0) }
    var sharedName by remember { mutableStateOf(sharedName0) }
    var countdownOn by remember(settings.countdown) { mutableStateOf(settings.countdown) }
    var countdown by remember { mutableStateOf<Int?>(null) }

    val lm = remember { ctx.getSystemService(LocationManager::class.java) }
    var hasPerm by remember { mutableStateOf(Tracking.hasLocationPermission(ctx)) }
    var locOn by remember { mutableStateOf(LocationManagerCompat.isLocationEnabled(lm)) }
    var signal by remember { mutableStateOf(SignalQuality.NONE) }
    var accuracy by remember { mutableStateOf<Float?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasPerm = Tracking.hasLocationPermission(ctx)
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    // Recalcular estado al volver de Ajustes
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) { hasPerm = Tracking.hasLocationPermission(ctx); locOn = LocationManagerCompat.isLocationEnabled(lm) } }
        lifecycle.addObserver(o); onDispose { lifecycle.removeObserver(o) }
    }
    // Comprobación de señal SOLO mientras esta pantalla está abierta. Se detiene al salir.
    DisposableEffect(hasPerm, locOn) {
        // Objeto completo (no lambda): en Android < 11 los demás métodos no tienen implementación por defecto.
        val l = object : LocationListener {
            override fun onLocationChanged(loc: android.location.Location) { accuracy = if (loc.hasAccuracy()) loc.accuracy else null; signal = signalFor(accuracy) }
            override fun onProviderEnabled(provider: String) { locOn = true }
            override fun onProviderDisabled(provider: String) { locOn = false; signal = SignalQuality.NONE }
            @Deprecated("Deprecated in API") override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
        }
        if (hasPerm && locOn) runCatching { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, l, Looper.getMainLooper()) }
        onDispose { lm.removeUpdates(l) }
    }

    LaunchedEffect(countdown) {
        val c = countdown ?: return@LaunchedEffect
        if (c > 0) { delay(1000); countdown = c - 1 } else {
            Tracking.start(ctx, kind, plannedId, routeId, sharedId, sharedName)
            nav.navigate(Routes.ACTIVE) { popUpTo(Routes.HOME) }
        }
    }

    val plannedName = planned.firstOrNull { it.id == plannedId }?.name
    val routeName = g.routes.byId(routeId)?.name

    Box(Modifier.fillMaxSize().background(C.Bg)) {
        ScreenScaffold("Preparar carrera", header = {
            Box(Modifier.size(44.dp).clip(CircleShape).background(C.Control).clickable { nav.popBackStack() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Close, "Cerrar", tint = C.Text)
            }
        }) {
            item {
                FCard(onClick = {
                    sheet.show {
                        Text("Tipo de sesión", style = T.Section)
                        Spacer(Modifier.height(10.dp))
                        ListRow("Carrera libre", leading = Icons.Rounded.DirectionsRun) { kind = RunKind.FREE; plannedId = null; routeId = null; sharedId = null; sheet.hide() }
                        val upcoming = planned.filter { it.state() == PlanState.PENDING && it.epochDay <= LocalDate.now().plusDays(2).toEpochDay() || it.state() == PlanState.MISSED && it.epochDay >= LocalDate.now().minusDays(2).toEpochDay() }
                        upcoming.forEach { p -> ListRow("Rutina: ${p.name}", Fmt.dateLong(LocalDate.ofEpochDay(p.epochDay)), leading = Icons.Rounded.Repeat) {
                            kind = RunKind.ROUTINE; plannedId = p.id; sheet.hide() } }
                        favorites.mapNotNull { g.routes.byId(it.routeId) }.forEach { r -> ListRow("Ruta: ${r.name}", "${Fmt.km(r.distanceM, 1)} km", leading = Icons.Rounded.Route) {
                            kind = RunKind.ROUTE; routeId = r.id; sheet.hide() } }
                        shared.filter { it.startAt > System.currentTimeMillis() - 6 * 3600_000 }.forEach { s -> ListRow("Conjunta: ${s.name}", s.meetingLabel, leading = Icons.Rounded.Groups) {
                            kind = RunKind.SHARED; sharedId = s.id; sharedName = s.name; sheet.hide() } }
                    }
                }) {
                    Text("Tipo", style = T.Label)
                    Text(when (kind) { RunKind.ROUTINE -> "Sesión de rutina: ${plannedName ?: ""}"; RunKind.ROUTE -> "Ruta guardada: ${routeName ?: ""}"
                        RunKind.SHARED -> "Sesión conjunta: ${sharedName ?: ""}"; else -> "Carrera libre" }, style = T.Section)
                    if (kind == RunKind.SHARED) Text("Tu registro queda en tu historial privado. No se comparte tu ubicación, tiempos ni recorrido.", style = T.Label)
                    Text("Cambiar", style = T.BodyStrong.copy(color = C.Blue), modifier = Modifier.padding(top = 6.dp))
                }
            }
            item {
                Notice("Usamos tu ubicación solo mientras registras una carrera, para medir distancia, velocidad y dibujar tu recorrido. " +
                    "Se guarda en este dispositivo. Al terminar o descartar, la captura se detiene.", icon = Icons.Rounded.LocationOn)
            }
            item {
                FCard {
                    CheckRow("Permiso de ubicación precisa", hasPerm, if (hasPerm) null else "Conceder") {
                        permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    }
                    CheckRow("Ubicación del dispositivo activada", locOn, if (locOn) null else "Activar") {
                        ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    }
                    if (Build.VERSION.SDK_INT >= 33) {
                        val notif = androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        CheckRow("Notificaciones (aviso visible de sesión activa y alertas)", notif, if (notif) null else "Permitir") {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(when (signal) {
                            SignalQuality.GOOD -> C.Green; SignalQuality.OK -> C.Blue; SignalQuality.WEAK -> C.Red; SignalQuality.NONE -> C.Grey }))
                        Spacer(Modifier.width(10.dp))
                        Text(signal.label + (accuracy?.let { " (±${it.toInt()} m)" } ?: ""), style = T.BodyStrong)
                    }
                    if (hasPerm && locOn && signal == SignalQuality.NONE)
                        Text("Buscando señal… Al aire libre suele tardar menos. Puedes empezar igualmente: los datos aparecerán cuando haya señal.", style = T.Label)
                }
            }
            item {
                FCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Cuenta atrás de 3 s", style = T.BodyStrong); Text("Opcional", style = T.Label) }
                        Switch(countdownOn, { countdownOn = it }, colors = SwitchDefaults.colors(checkedTrackColor = C.Green, checkedThumbColor = C.OnColor))
                    }
                }
            }
            item {
                PillButton("Empezar", color = C.Green, icon = Icons.Rounded.PlayArrow, big = true, enabled = hasPerm && locOn, modifier = Modifier.fillMaxWidth()) {
                    countdown = if (countdownOn) 3 else 0
                }
            }
            item { PillButton("Volver", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { nav.popBackStack() } }
        }
        countdown?.takeIf { it > 0 }?.let { c ->
            Box(Modifier.fillMaxSize().background(C.Bg.copy(alpha = 0.92f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$c", style = T.RunMetric.copy(fontSize = 120.sp))
                    Spacer(Modifier.height(20.dp))
                    PillButton("Cancelar", color = C.Control, textColor = C.Text) { countdown = null }
                }
            }
        }
    }
}

@Composable
private fun CheckRow(label: String, ok: Boolean, action: String?, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked, null, tint = if (ok) C.Green else C.TextSec)
        Spacer(Modifier.width(10.dp))
        Text(label, style = T.Body, modifier = Modifier.weight(1f))
        if (action != null) PillButton(action, color = C.Text) { onAction() }
    }
}
