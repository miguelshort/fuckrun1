package app.fuckrun.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import app.fuckrun.R

/** Paleta definida para fuckrun (no son colores oficiales de Revolut). */
object C {
    val Bg = Color(0xFF0B0C0F)
    val Surface = Color(0xFF15171C)
    val Card = Color(0xFF1E2128)
    val Control = Color(0xFF292D35)
    val Text = Color(0xFFF7F8FA)
    val TextSec = Color(0xFF9DA3AE)
    val Blue = Color(0xFF6C8CFF)
    val Green = Color(0xFF65D6A0)
    val Red = Color(0xFFF26B78)
    val OnColor = Color(0xFF0B0C0F)     // texto oscuro sobre botones de color (contraste)
    val Grey = Color(0xFF4A505C)
    val Border = Color(0x1AFFFFFF)
}

val Inter = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

/** -85 de interletreado = -0.085em (no píxeles). Solo en titulares importantes y nombre. */
private val Tight = (-0.085).em
private const val TNUM = "tnum"

object T {
    val RunMetric = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 56.sp, letterSpacing = (-0.03).em, fontFeatureSettings = TNUM, color = C.Text)
    val HomeFigure = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 46.sp, letterSpacing = Tight, fontFeatureSettings = TNUM, color = C.Text)
    val ScreenTitle = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = Tight, color = C.Text)
    val Section = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 21.sp, letterSpacing = (-0.04).em, color = C.Text)
    val Body = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 22.sp, color = C.Text)
    val BodyStrong = Body.copy(fontWeight = FontWeight.SemiBold)
    val Label = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 17.sp, color = C.TextSec)
    val Number = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 22.sp, fontFeatureSettings = TNUM, color = C.Text)
    val SmallNumber = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, fontFeatureSettings = TNUM, color = C.Text)
}

@Composable
fun FuckrunTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Blue, onPrimary = C.OnColor, secondary = C.Green, onSecondary = C.OnColor,
            error = C.Red, onError = C.OnColor, background = C.Bg, onBackground = C.Text,
            surface = C.Surface, onSurface = C.Text, surfaceVariant = C.Card, onSurfaceVariant = C.TextSec,
            outline = C.Control, surfaceContainerHigh = C.Card, surfaceContainer = C.Surface,
        ),
        typography = MaterialTheme.typography.let { t ->
            t.copy(
                bodyLarge = T.Body, bodyMedium = T.Body.copy(fontSize = 15.sp), bodySmall = T.Label,
                labelLarge = T.BodyStrong.copy(fontSize = 15.sp), labelMedium = T.Label, labelSmall = T.Label.copy(fontSize = 12.sp),
                titleLarge = T.Section, titleMedium = T.BodyStrong, headlineMedium = T.ScreenTitle,
            )
        },
        content = content,
    )
}
