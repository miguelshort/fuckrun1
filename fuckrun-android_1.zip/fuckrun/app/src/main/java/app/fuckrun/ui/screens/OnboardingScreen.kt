package app.fuckrun.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.AppSettings
import app.fuckrun.data.Municipality
import app.fuckrun.domain.*
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.DayOfWeek

@Composable
fun OnboardingScreen(nav: NavController) {
    val g = FuckrunApp.graph
    val scope = rememberCoroutineScope()
    val initial by produceState<AppSettings?>(null) { value = g.profile.settings.first() }
    val start = initial ?: return
    val editing = start.onboardingDone
    var a by remember { mutableStateOf(start.answers) }
    var step by remember { mutableIntStateOf(0) }
    val steps = 8

    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!editing && step == 0) Logo(height = 26.dp) else Text(if (editing) "Editar respuestas" else "Tu punto de partida", style = T.BodyStrong)
            Spacer(Modifier.weight(1f))
            Text("${step + 1}/$steps", style = T.Label)
        }
        LinearSteps(step, steps)
        AnimatedContent(step, modifier = Modifier.weight(1f), label = "paso") { s ->
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                when (s) {
                    0 -> {
                        Q("¿Qué buscas?")
                        ChoiceChips(Goal.entries, { it.label }, { it == a.goal }) { a = a.copy(goal = it) }
                        if (a.goal == Goal.TARGET) {
                            Sub("¿Qué distancia?")
                            ChoiceChips(TargetDistance.entries, { it.label }, { it == a.targetDistance }) { a = a.copy(targetDistance = it) }
                        }
                    }
                    1 -> {
                        Q("¿Corres actualmente?")
                        ChoiceChips(RunsNow.entries, { it.label }, { it == a.runsNow }) { a = a.copy(runsNow = it) }
                        if (a.runsNow != RunsNow.NO) {
                            Sub("¿Cuántos días por semana?")
                            ChoiceChips((1..7).map { it as Int? } + listOf(null), { it?.toString() ?: "No lo sé" }, { it == a.daysPerWeekNow }) { a = a.copy(daysPerWeekNow = it) }
                        }
                    }
                    2 -> {
                        Q("¿Cuánto tiempo puedes correr seguido de forma cómoda?")
                        ChoiceChips(Continuous.entries, { it.label }, { it == a.continuous }) { a = a.copy(continuous = it) }
                        Sub("¿Qué distancia sueles completar? (si la conoces)")
                        ChoiceChips(UsualDistance.entries, { it.label }, { it == a.usualDistance }) { a = a.copy(usualDistance = it) }
                        Text("No necesitas saber tu ritmo ni tus distancias.", style = T.Label)
                    }
                    3 -> {
                        Q("¿Cuánto tiempo puedes dedicar a cada sesión?")
                        ChoiceChips(listOf(20, 30, 45, 60, 90), { "$it min" }, { it == a.sessionMinutes }) { a = a.copy(sessionMinutes = it) }
                        Sub("¿Cuántos días quieres entrenar?")
                        ChoiceChips((1..6).toList(), { "$it" }, { it == a.desiredDays }) { a = a.copy(desiredDays = it) }
                        Sub("¿Qué días tienes disponibles?")
                        ChoiceChips(DayOfWeek.values().toList(), { Fmt.dayShort(it) }, { it.value in a.availableDayNumbers }) {
                            a = a.copy(availableDayNumbers = a.availableDayNumbers.toggle(it.value))
                        }
                    }
                    4 -> {
                        Q("Tus preferencias")
                        Sub("¿Cómo prefieres correr?")
                        ChoiceChips(Social.entries, { it.label }, { it == a.social }) { a = a.copy(social = it) }
                        Sub("¿Dónde?")
                        ChoiceChips(Environment.entries, { it.label }, { it in a.environments }) { a = a.copy(environments = a.environments.toggle(it)) }
                        Sub("¿Desnivel?")
                        ChoiceChips(Elevation.entries, { it.label }, { it == a.elevation }) { a = a.copy(elevation = it) }
                        Sub("¿Tipo de ruta?")
                        ChoiceChips(RouteShape.entries, { it.label }, { it == a.routeShape }) { a = a.copy(routeShape = it) }
                    }
                    5 -> {
                        Q("¿Dónde vives?")
                        Text("Solo sirve para buscar recorridos. No se usa para estimar tu nivel.", style = T.Label)
                        MunicipalityPicker(a.municipality?.let { m -> a.province?.let { p -> m to p } }) { m ->
                            a = a.copy(municipality = m?.name, province = m?.province)
                        }
                    }
                    6 -> {
                        Q("¿Hay algo que quieras tener en cuenta?")
                        Text("Opcional. No te pedimos diagnósticos. Si lo indicas, mantendremos las propuestas suaves y podrás sustituirlas por descanso o por lo que te hayan indicado.", style = T.Label)
                        ChoiceChips(Limitation.entries, { it.label }, { it == a.limitation }) { a = a.copy(limitation = it) }
                        if (a.limitation == Limitation.SOMETHING) Field(a.limitationNote, "Nota opcional para ti (no se comparte)") { a = a.copy(limitationNote = it) }
                    }
                    else -> {
                        val r = LevelClassifier.classify(a)
                        Text("Punto de partida orientativo", style = T.Label)
                        Text(r.level.label, style = T.HomeFigure)
                        Text(r.level.description, style = T.Body)
                        FCard {
                            Text("Por qué", style = T.Label)
                            r.reasons.forEach { Text("• $it", style = T.Body) }
                            Spacer(Modifier.height(6.dp))
                            Text("Se basa solo en lo que has contado sobre tu experiencia. No es una evaluación médica ni un resultado exacto.", style = T.Label)
                        }
                        Sub("¿No encaja? Puedes cambiarlo")
                        ChoiceChips(Level.entries, { it.label }, { it == r.level }) { a = a.copy(levelOverride = it) }
                    }
                }
            }
        }
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (step > 0) PillButton("Atrás", color = C.Control, textColor = C.Text, modifier = Modifier.weight(1f)) { step-- }
            else if (editing) PillButton("Cancelar", color = C.Control, textColor = C.Text, modifier = Modifier.weight(1f)) { nav.popBackStack() }
            if (step < steps - 1) PillButton(if (step == 5 && a.municipality == null || step == 6 && a.limitation == Limitation.NONE) "Omitir" else "Siguiente",
                color = C.Text, modifier = Modifier.weight(1f)) { step++ }
            else PillButton(if (editing) "Guardar cambios" else "Empezar", color = C.Green, modifier = Modifier.weight(1f)) {
                scope.launch {
                    g.profile.update { it.copy(answers = a, onboardingDone = true) }
                    if (editing) nav.popBackStack() else nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                }
            }
        }
    }
}

private fun <E> Set<E>.toggle(e: E) = if (e in this) this - e else this + e

@Composable private fun Q(t: String) = Text(t, style = T.ScreenTitle)
@Composable private fun Sub(t: String) = Text(t, style = T.BodyStrong, modifier = Modifier.padding(top = 8.dp))

@Composable
private fun LinearSteps(step: Int, total: Int) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(total) { i -> Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)).background(if (i <= step) C.Blue else C.Control)) }
    }
}

@Composable
fun Field(value: String, placeholder: String, singleLine: Boolean = false, onChange: (String) -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(C.Card).padding(16.dp)) {
        if (value.isEmpty()) Text(placeholder, style = T.Body.copy(color = C.TextSec))
        BasicTextField(value, onChange, textStyle = T.Body, cursorBrush = SolidColor(C.Blue), singleLine = singleLine, modifier = Modifier.fillMaxWidth())
    }
}

/** Buscador de municipio y provincia. Los nombres repetidos se distinguen por la provincia. */
@Composable
fun MunicipalityPicker(selected: Pair<String, String>?, onSelect: (Municipality?) -> Unit) {
    val idx = FuckrunApp.graph.municipalities
    var q by remember { mutableStateOf("") }
    if (selected != null) {
        FCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Place, null, tint = C.Blue)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text(selected.first, style = T.BodyStrong); Text(selected.second, style = T.Label) }
            }
            Spacer(Modifier.height(8.dp))
            PillButton("Cambiar municipio", color = C.Control, textColor = C.Text) { onSelect(null) }
        }
        return
    }
    Field(q, "Busca municipio o provincia", singleLine = true) { q = it }
    val results = remember(q) { idx.search(q) }
    Column {
        results.forEach { m ->
            ListRow(m.name, m.province + if (idx.isAmbiguous(m)) " · hay otros municipios con este nombre" else "", leading = Icons.Rounded.Place) { onSelect(m) }
        }
        if (results.isEmpty()) Text("Sin resultados. El listado completo del INE puede cargarse siguiendo docs/RUTAS.md.", style = T.Label)
    }
}
