package app.fuckrun.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.AppSettings
import app.fuckrun.data.LatLon
import app.fuckrun.data.PrimaryMetric
import app.fuckrun.data.db.RunStatus
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.NO_DATA
import app.fuckrun.domain.metrics.RunMetrics
import app.fuckrun.tracking.SignalQuality
import app.fuckrun.tracking.Tracking
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ActiveRunScreen(nav: NavController) {
    val ctx = LocalContext.current
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    val live by Tracking.live.collectAsStateWithLifecycle()
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    var locked by remember { mutableStateOf(false) }
    fun minimize() { if (!nav.popBackStack(Routes.HOME, false)) nav.navigate(Routes.HOME) }

    BackHandler { minimize() }   // minimizar nunca detiene la grabación

    var waited by remember { mutableIntStateOf(0) }
    LaunchedEffect(live == null) { while (live == null && waited < 8) { delay(1000); waited++ } }
    val l = live
    if (l == null) {
        Box(Modifier.fillMaxSize().background(C.Bg), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (waited < 8) "Iniciando registro…" else "No hay ninguna sesión activa", style = T.Section)
                if (waited >= 8) { Spacer(Modifier.height(12.dp)); PillButton("Volver", color = C.Control, textColor = C.Text) { minimize() } }
            }
        }
        return
    }
    val s = l.stats
    val paused = l.status == RunStatus.PAUSED

    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding()) {
        // Barra superior: minimizar, estado y bloqueo
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.clip(RoundedCornerShape(50)).background(C.Control).clickable(enabled = !locked) { minimize() }.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.KeyboardArrowDown, null, tint = C.Text); Text(" Minimizar", style = T.BodyStrong)
            }
            Spacer(Modifier.weight(1f))
            Tag(if (paused) "En pausa" else "Grabando", if (paused) C.Red else C.Green, C.OnColor)
            Spacer(Modifier.width(8.dp))
            Tag(l.signal.label, when (l.signal) { SignalQuality.GOOD -> C.Control; SignalQuality.OK -> C.Control; else -> C.Red.copy(alpha = 0.3f) })
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            l.warnings.forEach { Notice(it.text, color = C.Red.copy(alpha = 0.18f), icon = Icons.Rounded.Warning) }
            Text(l.kindLabel, style = T.Label, modifier = Modifier.padding(start = 4.dp))
            // Métrica principal (elegible)
            val (pLabel, pValue, pUnit) = metric(settings.primaryMetric, s)
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(C.Card)
                .clickable(enabled = !locked) {
                    sheet.pick("Métrica principal", PrimaryMetric.entries, { it.label }, settings.primaryMetric) { m -> scope.launch { g.profile.update { it.copy(primaryMetric = m) } } }
                }.padding(20.dp)) {
                Text("$pLabel · toca para cambiar", style = T.Label)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(pValue, style = T.RunMetric.copy(fontSize = 64.sp))
                    if (pUnit.isNotEmpty()) Text(" $pUnit", style = T.Section.copy(color = C.TextSec), modifier = Modifier.padding(bottom = 10.dp))
                }
            }
            MetricGrid(listOf(
                Triple("Tiempo transcurrido", Fmt.duration(s?.elapsedMs), ""),
                Triple("Tiempo activo", Fmt.duration(s?.activeMs), ""),
                Triple("Distancia", Fmt.km(s?.distanceM), "km"),
                Triple("Velocidad actual", Fmt.kmh(s?.currentSpeedMps), "km/h"),
                Triple("Velocidad media", Fmt.kmh(s?.avgSpeedMps), "km/h"),
                Triple("Velocidad máxima", Fmt.kmh(s?.maxSpeedMps), "km/h"),
                Triple("Vel. mínima en mov.", Fmt.kmh(s?.minMovingSpeedMps), "km/h"),
                Triple("Ritmo actual", Fmt.pace(s?.currentPaceSecPerKm), "min/km"),
                Triple("Ritmo medio", Fmt.pace(s?.avgPaceSecPerKm), "min/km"),
            ))
            RunMap(s?.segments?.map { seg -> seg.map { LatLon(it.lat, it.lon) } } ?: emptyList(),
                Modifier.fillMaxWidth().height(220.dp), follow = true, interactive = !locked)
            Text("“$NO_DATA” = sin datos suficientes todavía. La línea discontinua del mapa marca tramos sin señal.", style = T.Label)
            Spacer(Modifier.height(8.dp))
        }
        // Controles grandes
        Box(Modifier.fillMaxWidth().padding(16.dp)) {
            if (locked) UnlockBar { locked = false }
            else Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(64.dp).clip(CircleShape).background(C.Control).clickable(role = Role.Button) { locked = true }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Lock, "Bloquear controles", tint = C.Text)
                }
                if (paused) PillButton("Reanudar", color = C.Green, icon = Icons.Rounded.PlayArrow, big = true, modifier = Modifier.weight(1f)) { Tracking.resume(ctx) }
                else PillButton("Pausar", color = C.Red, icon = Icons.Rounded.Pause, big = true, modifier = Modifier.weight(1f)) { Tracking.pause(ctx) }
                PillButton("Terminar", color = C.Blue, icon = Icons.Rounded.Flag, big = true, modifier = Modifier.weight(1f)) {
                    sheet.confirm("¿Terminar la sesión?", "Se detendrá la grabación. Después podrás guardarla o descartarla.", "Terminar", C.Blue) { Tracking.stop(ctx) }
                }
            }
        }
    }
}

private fun metric(m: PrimaryMetric, s: RunMetrics.Stats?): Triple<String, String, String> = when (m) {
    PrimaryMetric.TIME -> Triple("Tiempo activo", Fmt.duration(s?.activeMs), "")
    PrimaryMetric.DISTANCE -> Triple("Distancia", Fmt.km(s?.distanceM), "km")
    PrimaryMetric.PACE -> Triple("Ritmo actual", Fmt.pace(s?.currentPaceSecPerKm), "min/km")
    PrimaryMetric.SPEED -> Triple("Velocidad actual", Fmt.kmh(s?.currentSpeedMps), "km/h")
}

@Composable
private fun MetricGrid(items: List<Triple<String, String, String>>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (label, value, unit) ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(C.Surface).padding(14.dp)) {
                        Text(label, style = T.Label, maxLines = 1)
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(value, style = T.Number.copy(fontSize = 28.sp))
                            if (unit.isNotEmpty() && value != NO_DATA) Text(" $unit", style = T.Label, modifier = Modifier.padding(bottom = 4.dp))
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

/** Desbloqueo visible: mantener pulsado 1,2 s con barra de progreso. */
@Composable
private fun UnlockBar(onUnlock: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    Box(Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(50)).background(C.Control)
        .pointerInput(Unit) {
            detectTapGestures(onPress = {
                val job = scope.launch { progress.animateTo(1f, tween(1200, easing = LinearEasing)); onUnlock() }
                tryAwaitRelease()
                if (progress.value < 1f) { job.cancel(); scope.launch { progress.animateTo(0f) } }
            })
        }, contentAlignment = Alignment.Center) {
        Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(progress.value).background(C.Text.copy(alpha = 0.18f)))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.LockOpen, null, tint = C.Text)
            Text("  Mantén pulsado para desbloquear", style = T.BodyStrong)
        }
    }
}
