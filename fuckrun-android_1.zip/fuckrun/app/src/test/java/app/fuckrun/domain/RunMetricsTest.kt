package app.fuckrun.domain

import app.fuckrun.domain.metrics.RunMetrics
import app.fuckrun.domain.metrics.RunMetrics.Interval
import app.fuckrun.domain.metrics.RunMetrics.Sample
import org.junit.Assert.*
import org.junit.Test
import java.time.DayOfWeek

class RunMetricsTest {
    // ~1 m de latitud = 1/111_195 grados
    private val degPerM = 1.0 / 111_195.0
    private fun line(seg: Int, startMs: Long, n: Int, mps: Double, acc: Float = 5f, lat0: Double = 40.0) =
        (0 until n).map { i -> Sample(seg, startMs + i * 1000L, startMs + i * 1000L, lat0 + i * mps * degPerM, -3.0, acc) }

    @Test fun constantSpeed_givesDistanceAveragesAndPace() {
        val pts = line(0, 0, 601, 3.0)   // 10 min a 3 m/s = 1800 m
        val s = RunMetrics.compute(pts, listOf(Interval(0, 600_000)), 0, 600_000, 600_000)
        assertEquals(1800.0, s.distanceM, 5.0)
        assertEquals(600_000, s.activeMs)
        assertEquals(3.0, s.avgSpeedMps!!, 0.02)
        assertEquals(333.3, s.avgPaceSecPerKm!!, 2.0)
        assertEquals(3.0, s.maxSpeedMps!!, 0.05)
        assertEquals(3.0, s.minMovingSpeedMps!!, 0.05)
        assertEquals(1, s.splits.count { !it.partial })
        assertEquals(333_000.0, s.splits.first().durationMs.toDouble(), 1500.0)
    }

    @Test fun singleGpsJump_isRejected_andDoesNotSetMax() {
        val pts = line(0, 0, 60, 3.0).toMutableList()
        val bad = pts[30].copy(lat = pts[30].lat + 500 * degPerM)   // salto de 500 m en 1 s
        pts[30] = bad
        val s = RunMetrics.compute(pts, listOf(Interval(0, 59_000)), 0, 59_000, 59_000)
        assertTrue(s.rejectedPoints >= 1)
        assertTrue("max ${s.maxSpeedMps}", s.maxSpeedMps!! < 4.0)
    }

    @Test fun inaccurateFixes_areIgnored() {
        val pts = line(0, 0, 30, 3.0, acc = 60f)
        val s = RunMetrics.compute(pts, listOf(Interval(0, 29_000)), 0, 29_000, 29_000)
        assertEquals(0.0, s.distanceM, 0.0)
        assertNull(s.avgSpeedMps)
        assertNull(s.maxSpeedMps)
        assertNull(s.minMovingSpeedMps)
    }

    @Test fun pauses_excludedFromActiveButIncludedInElapsed() {
        val a = line(0, 0, 61, 3.0)
        val b = line(1, 120_000, 61, 3.0, lat0 = a.last().lat)
        val s = RunMetrics.compute(a + b, listOf(Interval(0, 60_000), Interval(120_000, 180_000)), 0, 180_000, 180_000)
        assertEquals(180_000, s.elapsedMs)
        assertEquals(120_000, s.activeMs)
        assertEquals(360.0, s.distanceM, 5.0)
        assertEquals(3.0, s.avgSpeedMps!!, 0.05)
    }

    @Test fun gapBetweenSegments_addsNoDistance() {
        val a = line(0, 0, 11, 3.0)
        val b = line(1, 20_000, 11, 3.0, lat0 = a.last().lat + 2000 * degPerM)   // reaparece 2 km más allá
        val s = RunMetrics.compute(a + b, listOf(Interval(0, 30_000)), 0, 30_000, 30_000)
        assertEquals(60.0, s.distanceM, 3.0)
        assertEquals(2, s.segments.size)
    }

    @Test fun realStop_currentSpeedIsZero_minMovingExcludesStop() {
        val run = line(0, 0, 31, 3.0)
        val stop = (1..20).map { i -> run.last().copy(tMs = 30_000L + i * 1000, wallMs = 30_000L + i * 1000) }
        val s = RunMetrics.compute(run + stop, listOf(Interval(0, null)), 0, null, 50_000, nowMonotonicMs = 50_000, recording = true)
        assertEquals(0.0, s.currentSpeedMps!!, 0.0001)
        assertNull(s.currentPaceSecPerKm)
        assertTrue(s.minMovingSpeedMps!! >= RunMetrics.MOVING_THRESHOLD_MPS)
    }

    @Test fun staleFix_currentSpeedIsNoData() {
        val run = line(0, 0, 31, 3.0)
        val s = RunMetrics.compute(run, listOf(Interval(0, null)), 0, null, 60_000, nowMonotonicMs = 60_000, recording = true)
        assertNull(s.currentSpeedMps)
    }

    @Test fun notEnoughData_noInventedValues() {
        val s = RunMetrics.compute(line(0, 0, 2, 3.0), listOf(Interval(0, 1000)), 0, 1000, 1000)
        assertNull(s.maxSpeedMps)
        assertNull(s.minMovingSpeedMps)
        assertTrue(s.splits.isEmpty())
    }

    @Test fun stationaryJitter_addsAlmostNoDistance() {
        val r = java.util.Random(7)
        val pts = (0 until 300).map { i -> Sample(0, i * 1000L, i * 1000L, 40.0 + (r.nextGaussian() * 2.0) * degPerM, -3.0 + (r.nextGaussian() * 2.0) * degPerM * 1.3, 6f) }
        val s = RunMetrics.compute(pts, listOf(Interval(0, 299_000)), 0, 299_000, 299_000)
        assertTrue("distancia fantasma ${s.distanceM}", s.distanceM < 60)
    }

    @Test fun slowWalk_isMeasured() {
        val pts = line(0, 0, 301, 1.4)   // 5 min a 1,4 m/s = 420 m
        val s = RunMetrics.compute(pts, listOf(Interval(0, 300_000)), 0, 300_000, 300_000)
        assertEquals(420.0, s.distanceM, 15.0)
    }

    @Test fun beginner_getsWalkRunByTime() {
        val a = OnboardingAnswers(goal = Goal.START, runsNow = RunsNow.NO, continuous = Continuous.NONE, sessionMinutes = 30)
        assertEquals(Level.INICIO, LevelClassifier.classify(a).level)
        val p = RecommendationEngine.proposal(a)
        assertEquals(SessionType.WALK_RUN, p.type)
        assertTrue(p.usedAnswers.isNotEmpty())
        assertTrue(p.mainMinutes <= 20)
    }

    @Test fun cityDoesNotAffectLevel() {
        val a = OnboardingAnswers(runsNow = RunsNow.YES, daysPerWeekNow = 4, continuous = Continuous.M30_60)
        assertEquals(LevelClassifier.classify(a).level, LevelClassifier.classify(a.copy(municipality = "Madrid", province = "Madrid")).level)
        assertEquals(Level.CONTINUIDAD, LevelClassifier.classify(a).level)
    }

    @Test fun limitation_keepsItSoft() {
        val a = OnboardingAnswers(runsNow = RunsNow.YES, daysPerWeekNow = 4, continuous = Continuous.M30_60, limitation = Limitation.SOMETHING)
        val p = RecommendationEngine.proposal(a)
        assertEquals(Intensity.VERY_EASY, p.intensity)
        assertNotNull(p.cautionNote)
        assertTrue(RecommendationEngine.weekly(a).days.none { it.second.type == SessionType.EASY_STRIDES })
    }

    @Test fun spread_separatesDays() {
        val all = DayOfWeek.values().toList()
        val d = RecommendationEngine.spread(all, 3).map { it.value }
        val gaps = d.zipWithNext { x, y -> y - x } + (d.first() + 7 - d.last())
        assertTrue("dias $d", gaps.min() >= 2)
    }
}
