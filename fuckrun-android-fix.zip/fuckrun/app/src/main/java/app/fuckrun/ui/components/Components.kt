@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package app.fuckrun.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.fuckrun.R
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import dev.chrisbanes.haze.*

// ---------- Desenfoque real del fondo (Haze: RenderEffect en Android 12+, superficie opaca en anteriores) ----------

val LocalHaze = staticCompositionLocalOf { HazeState() }
/** Espacio que hay que reservar al final del contenido para que la cápsula no tape nada. */
val LocalNavPadding = compositionLocalOf { 0.dp }

val GlassStyle = HazeStyle(
    backgroundColor = C.Bg,
    tints = listOf(HazeTint(C.Surface.copy(alpha = 0.70f))),
    blurRadius = 24.dp,
    noiseFactor = 0f,
    fallbackTint = HazeTint(C.Surface.copy(alpha = 0.97f)),   // sin desenfoque real: superficie más opaca
)

/** El desenfoque afecta solo al fondo; el contenido del panel se dibuja encima, nítido. */
fun Modifier.glass(shape: androidx.compose.ui.graphics.Shape, haze: HazeState) = this
    .clip(shape)
    .hazeChild(state = haze, style = GlassStyle)
    .border(1.dp, C.Border, shape)

/** Difuminación superior: el contenido que sale por arriba pierde opacidad progresivamente. Solo afecta al área desplazable. */
fun Modifier.topFade(height: Dp, enabled: Boolean) = if (!enabled) this else this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val h = height.toPx()
        drawRect(
            brush = Brush.verticalGradient(0f to Color.Transparent, 1f to Color.Black, startY = 0f, endY = h),
            size = Size(size.width, h), blendMode = BlendMode.DstIn,
        )
    }

// ---------- Navegación inferior flotante ----------

data class NavItem(val route: String, val label: String, val icon: ImageVector)

@Composable
fun FloatingNavBar(items: List<NavItem>, current: String?, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    val haze = LocalHaze.current
    val shape = RoundedCornerShape(percent = 50)
    Row(
        modifier
            .padding(horizontal = 18.dp)
            .shadow(16.dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
            .glass(shape, haze)
            .fillMaxWidth()
            .heightIn(min = 66.dp)
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEach { item ->
            val selected = item.route == current
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(percent = 50))
                    .background(if (selected) C.Text.copy(alpha = 0.10f) else Color.Transparent)
                    .clickable(role = Role.Tab) { onSelect(item.route) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(item.icon, null, tint = if (selected) C.Text else C.TextSec.copy(alpha = 0.85f), modifier = Modifier.size(22.dp))
                Spacer(Modifier.height(2.dp))
                Text(item.label, style = T.Label.copy(fontSize = 11.sp,
                    color = if (selected) C.Text else C.TextSec), maxLines = 1)
            }
        }
    }
}

// ---------- Hojas inferiores / selectores / menús con fondo desenfocado ----------

class SheetController {
    var content by mutableStateOf<(@Composable ColumnScope.() -> Unit)?>(null)
        private set
    fun show(c: @Composable ColumnScope.() -> Unit) { content = c }
    fun hide() { content = null }

    fun confirm(title: String, message: String, confirmLabel: String, color: Color, onConfirm: () -> Unit) = show {
        Text(title, style = T.Section)
        Spacer(Modifier.height(8.dp))
        Text(message, style = T.Body.copy(color = C.TextSec))
        Spacer(Modifier.height(20.dp))
        PillButton(confirmLabel, color = color, modifier = Modifier.fillMaxWidth()) { hide(); onConfirm() }
        Spacer(Modifier.height(10.dp))
        PillButton("Cancelar", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { hide() }
    }

    fun <O> pick(title: String, options: List<O>, label: (O) -> String, selected: O?, onPick: (O) -> Unit) = show {
        Text(title, style = T.Section)
        Spacer(Modifier.height(12.dp))
        options.forEach { o ->
            ListRow(label(o), trailing = if (o == selected) Icons.Rounded.Check else null) { hide(); onPick(o) }
        }
    }
}

val LocalSheet = staticCompositionLocalOf { SheetController() }

@Composable
fun SheetHost(controller: SheetController) {
    val haze = LocalHaze.current
    val content = controller.content
    BackHandler(enabled = content != null) { controller.hide() }
    AnimatedVisibility(content != null, enter = fadeIn(), exit = fadeOut()) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { controller.hide() })
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        AnimatedVisibility(content != null, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp, bottomStart = 28.dp, bottomEnd = 28.dp)
            Column(
                Modifier.padding(horizontal = 10.dp).navigationBarsPadding().imePadding().padding(bottom = 10.dp)
                    .glass(shape, haze).fillMaxWidth().heightIn(max = 640.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                    .verticalScroll(rememberScrollState()).padding(20.dp),
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).size(36.dp, 4.dp).clip(CircleShape).background(C.TextSec.copy(alpha = 0.5f)))
                Spacer(Modifier.height(14.dp))
                content?.invoke(this)
            }
        }
    }
}

// ---------- Botones y bloques ----------

@Composable
fun PillButton(
    text: String, modifier: Modifier = Modifier, color: Color = C.Blue, textColor: Color = C.OnColor,
    icon: ImageVector? = null, enabled: Boolean = true, big: Boolean = false, onClick: () -> Unit,
) {
    Row(
        modifier.heightIn(min = if (big) 64.dp else 52.dp).clip(RoundedCornerShape(percent = 50))
            .background(if (enabled) color else C.Control.copy(alpha = 0.6f))
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick).padding(horizontal = 22.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) { Icon(icon, null, tint = if (enabled) textColor else C.TextSec, modifier = Modifier.size(if (big) 26.dp else 20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, style = (if (big) T.BodyStrong.copy(fontSize = 18.sp) else T.BodyStrong)
            .copy(color = if (enabled) textColor else C.TextSec), textAlign = TextAlign.Center)
    }
}

@Composable
fun CircleAction(icon: ImageVector, label: String, tint: Color = C.Text, bg: Color = C.Control, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp)) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(bg).clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, style = T.Label.copy(color = C.Text), textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
fun FCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, color: Color = C.Card, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(color)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(18.dp),
        content = content,
    )
}

@Composable
fun ListRow(title: String, subtitle: String? = null, leading: ImageVector? = null, leadingTint: Color = C.Text,
            trailing: ImageVector? = Icons.Rounded.ChevronRight, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(C.Control), contentAlignment = Alignment.Center) { Icon(leading, null, tint = leadingTint, modifier = Modifier.size(20.dp)) }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = T.BodyStrong)
            if (subtitle != null) Text(subtitle, style = T.Label)
        }
        if (trailing != null && onClick != null) Icon(trailing, null, tint = C.TextSec)
    }
}

@Composable
fun Stat(label: String, value: String, unit: String? = null, modifier: Modifier = Modifier, big: Boolean = false) {
    Column(modifier) {
        Text(label, style = T.Label)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, style = if (big) T.HomeFigure else T.Number)
            if (unit != null) { Spacer(Modifier.width(4.dp)); Text(unit, style = T.Label.copy(color = C.TextSec), modifier = Modifier.padding(bottom = 3.dp)) }
        }
    }
}

@Composable
fun Tag(text: String, color: Color = C.Control, textColor: Color = C.Text) {
    Text(text, style = T.Label.copy(color = textColor), modifier = Modifier.clip(RoundedCornerShape(50)).background(color).padding(horizontal = 10.dp, vertical = 4.dp))
}

@Composable
fun Logo(modifier: Modifier = Modifier, height: Dp = 28.dp) {
    // Imagen original del logo; solo se adapta el tamaño.
    Image(painterResource(R.drawable.fuckrun_logo), contentDescription = "fuckrun", modifier = modifier.height(height))
}

@Composable
fun <O> ChoiceChips(options: List<O>, label: (O) -> String, isSelected: (O) -> Boolean, onToggle: (O) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            val sel = isSelected(o)
            Text(label(o), style = T.Body.copy(color = if (sel) C.OnColor else C.Text),
                modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) C.Text else C.Control)
                    .clickable(role = Role.Checkbox) { onToggle(o) }.padding(horizontal = 16.dp, vertical = 11.dp))
        }
    }
}

/**
 * Pantalla con cabecera fija y lista desplazable. La lista reserva espacio para la cápsula inferior
 * y aplica la difuminación superior solo cuando hay contenido saliendo por arriba.
 */
@Composable
fun ScreenScaffold(
    title: String?,
    header: (@Composable RowScope.() -> Unit)? = null,
    state: LazyListState = rememberLazyListState(),
    content: LazyListScope.() -> Unit,
) {
    val fade = 32.dp
    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (title != null) Text(title, style = T.ScreenTitle, modifier = Modifier.weight(1f)) else Spacer(Modifier.weight(1f))
            header?.invoke(this)
        }
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize().topFade(fade, state.canScrollBackward),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = LocalNavPadding.current + 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

@Composable
fun SectionTitle(text: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp, start = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = T.Section, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) Text(action, style = T.BodyStrong.copy(color = C.Blue), modifier = Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onAction).padding(8.dp))
    }
}

@Composable
fun Notice(text: String, color: Color = C.Control, icon: ImageVector = Icons.Rounded.Info, textColor: Color = C.Text) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(color).padding(14.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = textColor, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = T.Body.copy(color = textColor, fontSize = 14.sp))
    }
}

@Composable
fun rememberNavHeight(onHeight: (Dp) -> Unit): Modifier {
    val d = LocalDensity.current
    return Modifier.onSizeChanged { onHeight(with(d) { it.height.toDp() }) }
}
